﻿namespace Loans.Domain.Applications
{
    public class ScoreValue
    {
        public virtual int Score { get; }
    }
}