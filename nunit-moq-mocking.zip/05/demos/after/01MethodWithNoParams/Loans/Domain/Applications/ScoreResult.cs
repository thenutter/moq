﻿namespace Loans.Domain.Applications
{
    public class ScoreResult
    {
        public virtual ScoreValue ScoreValue { get; }
    }
}